

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.*;
/**
 * Servlet implementation class LoginSer
 */
@WebServlet("/LoginSer")
public class LoginSer extends HttpServlet {

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try
		{
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/stuinfodb","root","");
		Statement st = conn.createStatement();
		ResultSet res = st.executeQuery("select * from reg where username ='"+request.getParameter("txtuser")+"' and password='"+request.getParameter("txtpass")+"'");
		if(res.next())
		{
			HttpSession session = request.getSession();
			session.setAttribute("key",request.getParameter("txtuser"));
	        response.sendRedirect("showuser.jsp");	
		}
		else
		{
			response.sendRedirect("login.jsp?q=inavalid userid and password");
		}
		}
		catch(Exception ex)
		{
			
		}
	}

}
